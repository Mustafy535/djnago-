# Django
FCI Luxor Web Programming Level 4 
Download DJ.zip file
Copy to your pycharm projects directory
unzip
Activate your Virtual env
run:$ python manage.py runserver
